package UI;

import java.util.Date;

public class Account {
	private int id;
	private double balance;
	private double annualInterestRate = 0;
	private Date dateCreated;
	
	public Account() { // default constructor
		
	}
	public Account(int _id, double _balance) { // constructor
		balance = _balance;
		this.id = _id;
		this.dateCreated = new Date();
	}
	
	public int getid() { // returns the ID
		return this.id;
	}
	
	public void setid(int _id) { // sets the ID
		this.id = _id;
	}
	
	public double getBalance() {   //returns the balance
		return this.balance;
	}
	
	public void setBalance(double _balance) {  //changes the balance
		this.balance = -balance;
	}
	
	public double getAnnualInterestRate() { // returns the AnnualInterestRate
		return this.annualInterestRate;
	}
	
	public void setAnnualInterestRate( double _annualInterestRate) { // changes the AnnualInterestRate
		this.annualInterestRate = _annualInterestRate;
	}
	
	public Date getDateCreated() { // returns the date the account was created
		return this.dateCreated;
	}
	
	public double getMonthlyInterestRate() { // returns the monthlyInterestRate
		return this.annualInterestRate/12;
	}
	
	public double getMonthlyInterest() { // returns the monthlyInterest
		return this.balance * this.annualInterestRate/1200; 
	}
	
	public void withdraw(double withdrawAmount) { // withdraws money
		this.balance -= withdrawAmount;
		System.out.print("amount withdrawn: " + withdrawAmount );
	}
	
	public void deposit(double depositAmount) { // deposits money
		this.balance += depositAmount;
		System.out.print("amount deposited: " + depositAmount );
	}
	
}
