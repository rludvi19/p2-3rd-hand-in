package UI;

public class test {
	
	public static void main(String[] args) {
		Account testAccount;
		testAccount = new Account(1122, 20000);
		testAccount.setAnnualInterestRate(4.5);
		testAccount.withdraw(2500);
		testAccount.deposit(3000);
		System.out.println("balance:" + testAccount.getBalance());
		System.out.println("Monthly Interest: " + testAccount.getMonthlyInterest());
		System.out.println("Date of Creation: " + testAccount.getDateCreated());
	}
}
